import { useEffect, useState, type ReactNode } from "react"

type IconName = "grid" | "database" | "bell" | "settings" | "plus" | "arrow" | "trend" | "check" | "warning" | "file" | "close" | "edit" | "chevron" | "moon" | "sun"

function Icon({ name, size = 18 }: { name: IconName size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </>
    ),
    database: (
      <>
        <ellipse cx="12" cy="5" rx="8" ry="3" />
        <path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5" />
        <path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
        <path d="M10 21h4" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
      </>
    ),
    plus: (
      <>
        <path d="M12 5v14M5 12h14" />
      </>
    ),
    arrow: (
      <>
        <path d="M5 12h14M13 6l6 6-6 6" />
      </>
    ),
    trend: (
      <>
        <path d="m3 17 6-6 4 4 8-9" />
        <path d="M15 6h6v6" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    warning: (
      <>
        <path d="M10.3 3.7 2.5 17.2A2 2 0 0 0 4.2 20h15.6a2 2 0 0 0 1.7-2.8L13.7 3.7a2 2 0 0 0-3.4 0Z" />
        <path d="M12 9v4M12 17h.01" />
      </>
    ),
    file: (
      <>
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" />
        <path d="M14 2v6h6M8 13h8M8 17h5" />
      </>
    ),
    close: (
      <>
        <path d="m6 6 12 12M18 6 6 18" />
      </>
    ),
    edit: (
      <>
        <path d="M12 20h9" />
        <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" />
      </>
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
    moon: <path d="M20.5 14.2A8.5 8.5 0 0 1 9.8 3.5 8.5 8.5 0 1 0 20.5 14.2Z" />,
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
      </>
    ),
  }
  return (
    <svg
      aria-hidden="true"
      className="icon"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

const kpis = [
  {
    id: 0,
    label: "Monthly revenue",
    value: "€128.4k",
    target: "€120k",
    delta: "+7.0%",
    tone: "good",
  },
  {
    id: 1,
    label: "Food cost",
    value: "34.2%",
    target: "≤ 32%",
    delta: "+2.2 pts",
    tone: "bad",
  },
  {
    id: 2,
    label: "Repeat customers",
    value: "41.8%",
    target: "40%",
    delta: "+1.8 pts",
    tone: "good",
  },
  {
    id: 3,
    label: "Team satisfaction",
    value: "7.6",
    target: "≥ 8.0",
    delta: "−0.4",
    tone: "watch",
  },
]

function StatusPill({ tone, children }: { tone: string children: ReactNode }) {
  return (
    <span className={`status ${tone}`}>
      <span className="status-dot" />
      {children}
    </span>
  )
}

function AppShell({
  children,
  page,
  setPage,
  openCreate,
  dark,
  toggleTheme,
}: {
  children: ReactNode
  page: string
  setPage: (page: string) => void
  openCreate: () => void
  dark: boolean
  toggleTheme: () => void
}) {
  const nav = [
    ["dashboard", "grid", "Dashboards"],
    ["sources", "database", "Data sources"],
    ["alerts", "bell", "Alerts"],
    ["settings", "settings", "Settings"],
  ] as const
  return (
    <div className={`app-shell ${dark ? "dark-theme" : ""}`}>
      <aside className="sidebar">
        <button
          className="brand"
          onClick={() => setPage("dashboard")}
          aria-label="dAIshi home"
        >
          <span className="brand-mark">d</span>
          <span>dAIshi</span>
        </button>
        <button className="new-dashboard" onClick={openCreate}>
          <Icon name="plus" size={17} />
          New dashboard
        </button>
        <nav aria-label="Primary navigation">
          {nav.map(([id, icon, label]) => (
            <button
              key={id}
              className={`nav-item ${page === id ? "active" : ""}`}
              onClick={() => setPage(id)}
            >
              <Icon name={icon} />
              <span>{label}</span>
              {id === "alerts" && <span className="nav-count">2</span>}
            </button>
          ))}
        </nav>
        <button
          className="theme-switch"
          onClick={toggleTheme}
          aria-label={`Switch to ${dark ? "light" : "dark"} mode`}
        >
          <Icon name={dark ? "sun" : "moon"} size={17} />
          <span>{dark ? "Light mode" : "Dark mode"}</span>
          <span className={`theme-toggle ${dark ? "on" : ""}`}>
            <span />
          </span>
        </button>
        <div className="sidebar-bottom">
          <div className="sample-label">
            <span className="sample-dot" />
            <div>
              <strong>Sample workspace</strong>
              <small>Fictional data only</small>
            </div>
          </div>
          <div className="profile">
            <span className="avatar">AC</span>
            <div>
              <strong>Alex Chen</strong>
              <small>Owner</small>
            </div>
            <Icon name="chevron" size={15} />
          </div>
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  )
}

function Dashboard({
  openDetail,
}: {
  openDetail: (kind: "kpi" | "warning", index: number) => void
}) {
  const [range, setRange] = useState("Last 6 months")
  const [editing, setEditing] = useState(false)
  return (
    <>
      <header className="page-header">
        <div>
          <p className="eyebrow">Dashboards / Restaurant overview</p>
          <h1>Northstar Kitchen</h1>
          <p className="subtitle">
            Performance against the plan for our second location
          </p>
        </div>
        <div className="header-actions">
          <button
            className={`secondary-button ${editing ? "selected" : ""}`}
            onClick={() => setEditing(!editing)}
          >
            <Icon name="edit" size={16} />
            {editing ? "Done editing" : "Edit dashboard"}
          </button>
        </div>
      </header>
      <div className="context-bar">
        <div>
          <span className="context-label">Period</span>
          <select
            aria-label="Dashboard period"
            value={range}
            onChange={(e) => setRange(e.target.value)}
          >
            <option>Last 6 months</option>
            <option>This quarter</option>
            <option>Last 12 months</option>
          </select>
        </div>
        <div>
          <span className="context-label">Compared with</span>
          <strong>Previous 6 months</strong>
        </div>
        <div>
          <span className="context-label">Last updated</span>
          <strong>Today, 09:42</strong>
        </div>
        <StatusPill tone="sample">Sample data</StatusPill>
      </div>
      {editing && (
        <div className="edit-banner">
          <Icon name="edit" size={17} />
          <span>
            <strong>Layout editing is on.</strong> Select any card to inspect
            its settings.
          </span>
        </div>
      )}
      <section className="section">
        <div className="section-heading">
          <div>
            <h2>Key performance</h2>
            <p>Four indicators tied to your expansion decision</p>
          </div>
          <button className="text-button">
            View calculations <Icon name="arrow" size={15} />
          </button>
        </div>
        <div className="kpi-grid">
          {kpis.map((kpi, index) => (
            <button
              className="kpi-card"
              key={kpi.label}
              onClick={() => openDetail("kpi", index)}
            >
              <div className="card-top">
                <span>{kpi.label}</span>
                <StatusPill tone={kpi.tone}>
                  {kpi.tone === "good"
                    ? "On track"
                    : kpi.tone === "bad"
                      ? "Needs attention"
                      : "Watch"}
                </StatusPill>
              </div>
              <div className="kpi-value">{kpi.value}</div>
              <div className="kpi-meta">
                <span>
                  Target <strong>{kpi.target}</strong>
                </span>
                <span className={kpi.tone}>{kpi.delta}</span>
              </div>
              <div className="card-footer">
                <span>Jan—Jun 2025</span>
                <span>
                  View evidence <Icon name="chevron" size={13} />
                </span>
              </div>
            </button>
          ))}
        </div>
      </section>
      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Revenue & cost trend</h2>
              <p>Monthly actuals against target</p>
            </div>
            <button className="more-button" aria-label="More chart options">
              •••
            </button>
          </div>
          <div className="legend">
            <span>
              <i className="legend-line dark" />
              Revenue
            </span>
            <span>
              <i className="legend-line green" />
              Target
            </span>
            <span>
              <i className="legend-line dashed" />
              Food cost
            </span>
          </div>
          <div className="chart">
            <div className="y-labels">
              <span>€140k</span>
              <span>€100k</span>
              <span>€60k</span>
              <span>€20k</span>
            </div>
            <svg
              viewBox="0 0 620 190"
              role="img"
              aria-label="Revenue increased from January to June, while food cost also rose"
            >
              <g className="grid-lines">
                <path d="M0 10H620M0 65H620M0 120H620M0 175H620" />
              </g>
              <path className="target-line" d="M0 65H620" />
              <path
                className="area"
                d="M0 145 C55 133 70 120 120 124 S200 104 245 108 S330 83 370 90 S450 66 495 72 S565 43 620 47 V175H0Z"
              />
              <path
                className="revenue-line"
                d="M0 145 C55 133 70 120 120 124 S200 104 245 108 S330 83 370 90 S450 66 495 72 S565 43 620 47"
              />
              <path
                className="cost-line"
                d="M0 148 C80 139 110 145 160 132 S250 125 310 115 S390 119 445 104 S540 91 620 95"
              />
            </svg>
            <div className="x-labels">
              <span>Jan</span>
              <span>Feb</span>
              <span>Mar</span>
              <span>Apr</span>
              <span>May</span>
              <span>Jun</span>
            </div>
          </div>
        </section>
        <section className="panel warnings-panel">
          <div className="panel-heading">
            <div>
              <h2>Needs your attention</h2>
              <p>2 prioritized changes</p>
            </div>
            <button className="text-button">View all</button>
          </div>
          <button
            className="warning-row"
            onClick={() => openDetail("warning", 0)}
          >
            <span className="warning-icon high">
              <Icon name="warning" size={17} />
            </span>
            <span className="warning-copy">
              <strong>Food costs are above plan</strong>
              <small>34.2% vs 32% target · 3 months rising</small>
            </span>
            <Icon name="chevron" size={16} />
          </button>
          <button
            className="warning-row"
            onClick={() => openDetail("warning", 1)}
          >
            <span className="warning-icon medium">
              <Icon name="trend" size={17} />
            </span>
            <span className="warning-copy">
              <strong>Team satisfaction softened</strong>
              <small>Down 0.6 points since March</small>
            </span>
            <Icon name="chevron" size={16} />
          </button>
          <div className="human-note">
            <Icon name="check" size={16} />
            <p>
              <strong>You remain in control.</strong>
              <br />
              dAIshi highlights evidence and possible issues. You decide what to
              do next.
            </p>
          </div>
        </section>
      </div>
    </>
  )
}

function Sources() {
  return (
    <>
      <header className="page-header">
        <div>
          <p className="eyebrow">Workspace</p>
          <h1>Data sources</h1>
          <p className="subtitle">
            Files supporting your dashboards and calculations
          </p>
        </div>
        <button className="primary-button">
          <Icon name="plus" size={16} />
          Add source
        </button>
      </header>
      <section className="panel table-panel">
        <div className="panel-heading">
          <div>
            <h2>Connected files</h2>
            <p>3 fictional sample files</p>
          </div>
        </div>
        {[
          "restaurant_finance_2025.xlsx",
          "customer_visits.csv",
          "team_pulse_q2.csv",
        ].map((file, i) => (
          <div className="source-row" key={file}>
            <span className="file-icon">
              <Icon name="file" />
            </span>
            <div>
              <strong>{file}</strong>
              <small>
                {i === 0
                  ? "1,248 rows · 12 fields"
                  : i === 1
                    ? "4,820 rows · 8 fields"
                    : "32 rows · 6 fields"}
              </small>
            </div>
            <span className="updated">
              {i === 0 ? "Updated today" : "Updated 2 days ago"}
            </span>
            <StatusPill tone="good">Validated</StatusPill>
            <button className="icon-button" aria-label={`View ${file}`}>
              <Icon name="chevron" size={16} />
            </button>
          </div>
        ))}
      </section>
    </>
  )
}

function Alerts({
  openDetail,
}: {
  openDetail: (kind: "kpi" | "warning", index: number) => void
}) {
  return (
    <>
      <header className="page-header">
        <div>
          <p className="eyebrow">Workspace</p>
          <h1>Alerts</h1>
          <p className="subtitle">Important changes, prioritized by impact</p>
        </div>
      </header>
      <section className="panel alerts-list">
        <div className="alert-large" onClick={() => openDetail("warning", 0)}>
          <span className="warning-icon high">
            <Icon name="warning" />
          </span>
          <div>
            <StatusPill tone="bad">High priority</StatusPill>
            <h3>Food costs are above plan</h3>
            <p>
              Food cost has reached 34.2%, now 2.2 points above your target and
              rising for three consecutive months.
            </p>
            <small>Northstar Kitchen · Updated today</small>
          </div>
          <Icon name="chevron" />
        </div>
        <div className="alert-large" onClick={() => openDetail("warning", 1)}>
          <span className="warning-icon medium">
            <Icon name="trend" />
          </span>
          <div>
            <StatusPill tone="watch">Medium priority</StatusPill>
            <h3>Team satisfaction softened</h3>
            <p>
              The latest team pulse is 0.4 points below target. Review
              shift-level comments before drawing a conclusion.
            </p>
            <small>Northstar Kitchen · Updated 2 days ago</small>
          </div>
          <Icon name="chevron" />
        </div>
      </section>
    </>
  )
}

function Settings({
  dark,
  toggleTheme,
}: {
  dark: boolean
  toggleTheme: () => void
}) {
  const [saved, setSaved] = useState(true)
  return (
    <>
      <header className="page-header">
        <div>
          <p className="eyebrow">Workspace</p>
          <h1>Settings</h1>
          <p className="subtitle">Prototype preferences and data controls</p>
        </div>
      </header>
      <section className="settings-grid">
        <div className="panel">
          <div className="panel-heading">
            <div>
              <h2>Local workspace</h2>
              <p>How this prototype stores information</p>
            </div>
          </div>
          <div className="setting-row">
            <div>
              <strong>Save dashboard state locally</strong>
              <p>Keep your sample workspace in this browser.</p>
            </div>
            <button
              className={`toggle ${saved ? "on" : ""}`}
              onClick={() => setSaved(!saved)}
              aria-label="Toggle local saving"
            >
              <span />
            </button>
          </div>
          <div className="setting-row">
            <div>
              <strong>Dark mode</strong>
              <p>Use a lower-glare interface throughout the workspace.</p>
            </div>
            <button
              className={`toggle ${dark ? "on" : ""}`}
              onClick={toggleTheme}
              aria-label="Toggle dark mode"
            >
              <span />
            </button>
          </div>
          <div className="setting-row">
            <div>
              <strong>Delete local data</strong>
              <p>Remove dashboards, mappings, and source metadata.</p>
            </div>
            <button className="danger-button">Delete data</button>
          </div>
        </div>
        <div className="privacy-card">
          <Icon name="database" size={22} />
          <h2>Prototype privacy</h2>
          <p>
            This is a front-end prototype. Data stays in this browser and is not
            sent to an external AI service.
          </p>
          <strong>Do not upload confidential company data.</strong>
        </div>
      </section>
    </>
  )
}

function DetailDrawer({
  detail,
  close,
}: {
  detail: { kind: "kpi" | "warning" index: number }
  close: () => void
}) {
  const isKpi = detail.kind === "kpi"
  const kpi = kpis[detail.index] || kpis[0]
  return (
    <div className="drawer-backdrop" onMouseDown={close}>
      <aside
        className="drawer"
        onMouseDown={(e) => e.stopPropagation()}
        aria-label="Evidence details"
      >
        <div className="drawer-header">
          <div>
            <p className="eyebrow">
              {isKpi ? "KPI evidence" : "Prioritized warning"}
            </p>
            <h2>
              {isKpi
                ? kpi.label
                : detail.index === 0
                  ? "Food costs are above plan"
                  : "Team satisfaction softened"}
            </h2>
          </div>
          <button
            className="icon-button"
            onClick={close}
            aria-label="Close details"
          >
            <Icon name="close" />
          </button>
        </div>
        {isKpi ? (
          <>
            <div className="detail-value">
              <span>Current value</span>
              <strong>{kpi.value}</strong>
              <StatusPill tone={kpi.tone}>
                {kpi.tone === "good"
                  ? "On track"
                  : kpi.tone === "bad"
                    ? "Needs attention"
                    : "Watch"}
              </StatusPill>
            </div>
            <div className="detail-section">
              <h3>Calculation</h3>
              <p>
                {detail.index === 0
                  ? "Sum of net sales for the selected period, excluding refunds and tax."
                  : detail.index === 1
                    ? "Ingredient and packaging costs ÷ net food revenue × 100."
                    : "Calculated from the latest validated source fields."}
              </p>
              <div className="formula">
                {detail.index === 1
                  ? "€43,913 ÷ €128,400 × 100 = 34.2%"
                  : `${kpi.value} for Jan—Jun 2025`}
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="insight">
              <span className="warning-icon high">
                <Icon name="warning" />
              </span>
              <p>
                {detail.index === 0
                  ? "Food cost is 2.2 points above target and has increased for three consecutive months."
                  : "Team satisfaction has moved 0.4 points below target, based on 28 responses."}
              </p>
            </div>
            <div className="detail-section">
              <h3>Why it matters</h3>
              <p>
                {detail.index === 0
                  ? "If the current revenue mix continues, the variance would reduce monthly gross profit by approximately €2.8k."
                  : "A sustained decline may affect service consistency during the expansion period."}
              </p>
            </div>
            <div className="detail-section">
              <h3>Possible next step</h3>
              <p>
                Review the supporting rows and confirm whether the change is
                operational or caused by a source update.
              </p>
            </div>
          </>
        )}
        <div className="detail-section">
          <h3>Source evidence</h3>
          <div className="evidence-file">
            <Icon name="file" />
            <div>
              <strong>
                {isKpi && detail.index === 3
                  ? "team_pulse_q2.csv"
                  : "restaurant_finance_2025.xlsx"}
              </strong>
              <small>
                {isKpi && detail.index === 3
                  ? "Field: satisfaction_score"
                  : "Sheet: Monthly P&L · Jan—Jun 2025"}
              </small>
            </div>
            <StatusPill tone="good">Validated</StatusPill>
          </div>
        </div>
        <div className="drawer-footer">
          <button className="secondary-button" onClick={close}>
            Close
          </button>
          <button className="primary-button">
            Review source <Icon name="arrow" size={16} />
          </button>
        </div>
      </aside>
    </div>
  )
}

function CreateModal({ close }: { close: () => void }) {
  const [step, setStep] = useState(1)
  const [choice, setChoice] = useState("restaurant")
  return (
    <div className="modal-backdrop">
      <div className="create-modal">
        <div className="modal-top">
          <div>
            <p className="eyebrow">Create dashboard</p>
            <h2>
              {step === 1
                ? "Choose a starting point"
                : step === 2
                  ? "What do you want to monitor?"
                  : "Ready to build"}
            </h2>
          </div>
          <button className="icon-button" onClick={close} aria-label="Close">
            <Icon name="close" />
          </button>
        </div>
        <div className="steps">
          {[1, 2, 3].map((n) => (
            <span className={step >= n ? "active" : ""} key={n}>
              {step > n ? <Icon name="check" size={13} /> : n}
            </span>
          ))}
        </div>
        {step === 1 && (
          <div className="choice-grid">
            <button
              className={choice === "restaurant" ? "selected" : ""}
              onClick={() => setChoice("restaurant")}
            >
              <span className="choice-mark">R</span>
              <strong>Restaurant sample</strong>
              <small>Revenue, food cost, customers & team</small>
            </button>
            <button
              className={choice === "consulting" ? "selected" : ""}
              onClick={() => setChoice("consulting")}
            >
              <span className="choice-mark">C</span>
              <strong>Consulting sample</strong>
              <small>Utilization, margin & active projects</small>
            </button>
          </div>
        )}
        {step === 2 && (
          <div className="goal-form">
            <label>
              Business goal
              <textarea
                defaultValue={
                  choice === "restaurant"
                    ? "Assess whether we are ready to open a second location"
                    : "Improve delivery margin while maintaining team capacity"
                }
              />
            </label>
            <div className="recommendations">
              <span>Recommended KPIs</span>
              <div>
                <StatusPill tone="sample">Revenue growth</StatusPill>
                <StatusPill tone="sample">Operating cost</StatusPill>
                <StatusPill tone="sample">Customer retention</StatusPill>
              </div>
            </div>
          </div>
        )}
        {step === 3 && (
          <div className="ready-state">
            <span className="ready-icon">
              <Icon name="check" size={28} />
            </span>
            <h3>Your sample workspace is ready</h3>
            <p>
              We’ll use fictional data to create a transparent dashboard with
              source references and prioritized warnings.
            </p>
            <div className="privacy-inline">
              <Icon name="warning" size={16} />
              Never upload confidential company data to this prototype.
            </div>
          </div>
        )}
        <div className="modal-footer">
          {step > 1 ? (
            <button
              className="secondary-button"
              onClick={() => setStep(step - 1)}
            >
              Back
            </button>
          ) : (
            <span />
          )}
          <button
            className="primary-button"
            onClick={() => (step < 3 ? setStep(step + 1) : close())}
          >
            {step < 3 ? "Continue" : "Create dashboard"}
            <Icon name="arrow" size={16} />
          </button>
        </div>
      </div>
    </div>
  )
}

export default function App() {
  const [page, setPage] = useState("dashboard")
  const [dark, setDark] = useState(
    () => localStorage.getItem("daishi-theme") === "dark",
  )
  const [detail, setDetail] = useState<{
    kind: "kpi" | "warning"
    index: number
  } | null>(null)
  const [creating, setCreating] = useState(false)
  useEffect(() => {
    const onKey = (event: KeyboardEvent) =>
      event.key === "Escape" && (setDetail(null), setCreating(false))
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [])
  useEffect(() => {
    localStorage.setItem("daishi-theme", dark ? "dark" : "light")
    document.documentElement.style.colorScheme = dark ? "dark" : "light"
  }, [dark])
  return (
    <AppShell
      page={page}
      setPage={setPage}
      openCreate={() => setCreating(true)}
      dark={dark}
      toggleTheme={() => setDark(!dark)}
    >
      <div className="content">
        {page === "dashboard" && (
          <Dashboard openDetail={(kind, index) => setDetail({ kind, index })} />
        )}
        {page === "sources" && <Sources />}
        {page === "alerts" && (
          <Alerts openDetail={(kind, index) => setDetail({ kind, index })} />
        )}
        {page === "settings" && (
          <Settings dark={dark} toggleTheme={() => setDark(!dark)} />
        )}
      </div>
      {detail && <DetailDrawer detail={detail} close={() => setDetail(null)} />}
      {creating && <CreateModal close={() => setCreating(false)} />}
    </AppShell>
  )
}
